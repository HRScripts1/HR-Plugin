# HR Plugin

Developer: **HRWasHere_**  
Target: **Paper 26.2 / Java 25**

## Build
Run `mvn package` with JDK 25 and internet access. The plugin JAR appears in `target/hr-plugin-1.0.0.jar`.

You can also push this project to GitHub; the included Actions workflow builds the JAR automatically.

## Install
1. Stop your Paper server and back up the world.
2. Upload `hr-plugin-1.0.0.jar` into `plugins/`.
3. Start the server.
4. Configure `plugins/HRPlugin/config.yml` after first start.

## Commands
`/hr`, `/menu`, `/setspawn`, `/spawn`, `/register <password> <repeat>`, `/login <password>`, `/balance`, `/pay <player> <amount>`, `/shop`, `/sell`, `/crates`, `/claim`, `/hrreload`.

## Important limitations in this starter
- Claims protect whole chunks; there are no trust/subclaim/claim-expiry tools yet.
- Shop buy prices are starter examples. Configure sell prices in `config.yml`.
- Crates are a simple free starter reward, not a key/loot-table crate economy.
- Anti-lag is a basic dropped-item/XP-orb cap, not a guarantee against every lag machine.
- Chat moderation is basic rate limiting and a small abusive-language rule; it is not a full moderation filter.
- The login system stores salted PBKDF2 password hashes, but is not a replacement for a dedicated authentication proxy on offline-mode networks. Use online-mode and secure server access where possible.
- Scoreboard currently shows player, balance, online count and developer footer. More stats/rank integrations can be added.
