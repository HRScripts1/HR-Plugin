package com.hrplugin;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class HRPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Long> lastChat = new ConcurrentHashMap<>();
    private final Set<UUID> loggedIn = ConcurrentHashMap.newKeySet();
    private final Map<String, UUID> claims = new HashMap<>();
    private final Map<UUID, Double> balances = new HashMap<>();
    private File usersFile, claimsFile, economyFile;
    private YamlConfiguration users, claimData, economy;
    private final String dev = "HRWasHere_";
    private final String menuTitle = ChatColor.DARK_BLUE + "HR " + ChatColor.AQUA + "Menu";

    @Override public void onEnable() {
        saveDefaultConfig();
        usersFile = new File(getDataFolder(), "users.yml");
        claimsFile = new File(getDataFolder(), "claims.yml");
        economyFile = new File(getDataFolder(), "economy.yml");
        users = YamlConfiguration.loadConfiguration(usersFile);
        claimData = YamlConfiguration.loadConfiguration(claimsFile);
        economy = YamlConfiguration.loadConfiguration(economyFile);
        for (String k : claimData.getKeys(false)) {
            try { claims.put(k, UUID.fromString(claimData.getString(k))); } catch (Exception ignored) {}
        }
        for (String k : economy.getKeys(false)) {
            try { balances.put(UUID.fromString(k), economy.getDouble(k)); } catch (Exception ignored) {}
        }
        for (String name : List.of("hr","menu","setspawn","spawn","register","login","balance","pay","shop","sell","crates","claim","hrreload")) {
            Objects.requireNonNull(getCommand(name)).setExecutor(this);
        }
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("HR Plugin enabled. Developer: " + dev);
        Bukkit.getScheduler().runTaskTimer(this, this::updateScoreboards, 20L, 40L);
    }

    @Override public void onDisable() { saveAll(); }
    private void saveAll() {
        try { users.save(usersFile); claimData.save(claimsFile); economy.save(economyFile); } catch (Exception e) { getLogger().severe("Could not save data: " + e.getMessage()); }
    }
    private boolean admin(CommandSender s) { return s.hasPermission("hr.admin") || (s instanceof Player p && p.getName().equalsIgnoreCase(dev)); }
    private boolean ready(Player p) {
        if (p.getName().equalsIgnoreCase(dev) || p.hasPermission("hr.bypass")) return true;
        if (!users.contains(p.getUniqueId().toString())) { p.sendMessage(ChatColor.YELLOW + "Register: /register <password> <repeat>"); return false; }
        if (!loggedIn.contains(p.getUniqueId())) { p.sendMessage(ChatColor.YELLOW + "Login: /login <password>"); return false; }
        return true;
    }
    private String hash(String input) throws Exception {
        byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
        var spec = new javax.crypto.spec.PBEKeySpec(input.toCharArray(), salt, 120000, 256);
        byte[] key = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        return Base64.getEncoder().encodeToString(salt) + ":" + Base64.getEncoder().encodeToString(key);
    }
    private boolean verify(String input, String stored) throws Exception {
        String[] parts = stored.split(":"); byte[] salt = Base64.getDecoder().decode(parts[0]);
        var spec = new javax.crypto.spec.PBEKeySpec(input.toCharArray(), salt, 120000, 256);
        byte[] key = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        return MessageDigest.isEqual(key, Base64.getDecoder().decode(parts[1]));
    }
    private double money(Player p) { return balances.getOrDefault(p.getUniqueId(), 0.0); }
    private void setMoney(Player p, double v) { balances.put(p.getUniqueId(), Math.max(0, v)); economy.set(p.getUniqueId().toString(), Math.max(0,v)); }
    private String chunkKey(Location l) { return l.getWorld().getName()+":"+l.getChunk().getX()+":"+l.getChunk().getZ(); }

    @Override public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String cmd = c.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("register") && s instanceof Player p) {
            if (users.contains(p.getUniqueId().toString())) { p.sendMessage(ChatColor.RED+"Already registered. Use /login."); return true; }
            if (a.length != 2 || a[0].length()<8 || !a[0].equals(a[1])) { p.sendMessage(ChatColor.RED+"Use /register <password> <repeat> (minimum 8 characters)."); return true; }
            try { users.set(p.getUniqueId().toString(), hash(a[0])); users.save(usersFile); loggedIn.add(p.getUniqueId()); p.sendMessage(ChatColor.GREEN+"Registered and logged in."); }
            catch(Exception ex) { p.sendMessage(ChatColor.RED+"Registration failed."); } return true;
        }
        if (cmd.equals("login") && s instanceof Player p) {
            if (a.length!=1 || !users.contains(p.getUniqueId().toString())) { p.sendMessage(ChatColor.RED+"Use /login <password>. Register first if needed."); return true; }
            try { if (verify(a[0], users.getString(p.getUniqueId().toString()))) { loggedIn.add(p.getUniqueId()); p.sendMessage(ChatColor.GREEN+"Login successful."); } else p.sendMessage(ChatColor.RED+"Incorrect password."); }
            catch(Exception ex) { p.sendMessage(ChatColor.RED+"Login failed."); } return true;
        }
        if (cmd.equals("hrreload")) { if(!admin(s)) return deny(s); reloadConfig(); s.sendMessage(ChatColor.GREEN+"HR Plugin config reloaded."); return true; }
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        if (cmd.equals("hr")) { p.sendMessage(ChatColor.AQUA+"HR Plugin by "+dev+" | /menu /spawn /shop /crates /claim"); return true; }
        if (cmd.equals("setspawn")) { if(!admin(p)) return deny(p); getConfig().set("spawn", serialize(p.getLocation())); saveConfig(); p.sendMessage(ChatColor.GREEN+"Spawn set."); return true; }
        if (cmd.equals("spawn")) { if(!ready(p)) return true; if(getConfig().isString("spawn")) p.teleport(deserialize(getConfig().getString("spawn"))); else p.sendMessage(ChatColor.RED+"Spawn is not set."); return true; }
        if (cmd.equals("menu")) { if(!ready(p)) return true; openMenu(p); return true; }
        if (cmd.equals("balance")) { if(!ready(p)) return true; p.sendMessage(ChatColor.GOLD+"Balance: $"+String.format(Locale.US,"%.2f",money(p))); return true; }
        if (cmd.equals("pay")) {
            if(!ready(p)) return true;
            if(a.length!=2) { p.sendMessage(ChatColor.RED+"/pay <player> <amount>"); return true; }
            Player target=Bukkit.getPlayerExact(a[0]); double amount;
            try { amount=Double.parseDouble(a[1]); } catch(Exception e) { p.sendMessage(ChatColor.RED+"Invalid amount."); return true; }
            if(target==null || target.equals(p) || amount<=0 || money(p)<amount) { p.sendMessage(ChatColor.RED+"Payment unavailable."); return true; }
            setMoney(p,money(p)-amount); setMoney(target,money(target)+amount); p.sendMessage(ChatColor.GREEN+"Paid $"+amount+" to "+target.getName()); target.sendMessage(ChatColor.GREEN+"Received $"+amount+" from "+p.getName()); return true;
        }
        if (cmd.equals("shop")) { if(!ready(p)) return true; openShop(p); return true; }
        if (cmd.equals("sell")) {
            if(!ready(p)) return true; ItemStack hand=p.getInventory().getItemInMainHand();
            if(hand.getType().isAir()) { p.sendMessage(ChatColor.RED+"Hold an item first."); return true; }
            double price=getConfig().getDouble("sell-prices."+hand.getType().name(), 0);
            if(price<=0) { p.sendMessage(ChatColor.RED+"This item has no sell price configured."); return true; }
            int amount=hand.getAmount(); hand.setAmount(0); setMoney(p,money(p)+price*amount); p.sendMessage(ChatColor.GREEN+"Sold "+amount+" items for $"+(price*amount)); return true;
        }
        if (cmd.equals("crates")) { if(!ready(p)) return true; openCrates(p); return true; }
        if (cmd.equals("claim")) {
            if(!ready(p)) return true;
            String key=chunkKey(p.getLocation()); UUID owner=claims.get(key);
            if(owner!=null && !owner.equals(p.getUniqueId())) { p.sendMessage(ChatColor.RED+"This chunk is already claimed."); return true; }
            claims.put(key,p.getUniqueId()); claimData.set(key,p.getUniqueId().toString()); p.sendMessage(ChatColor.GREEN+"Claimed this chunk."); return true;
        }
        return true;
    }
    private boolean deny(CommandSender s) { s.sendMessage(ChatColor.RED+"You don't have permission."); return true; }
    private String serialize(Location l) { return l.getWorld().getName()+","+l.getX()+","+l.getY()+","+l.getZ()+","+l.getYaw()+","+l.getPitch(); }
    private Location deserialize(String v) { String[] x=v.split(","); return new Location(Bukkit.getWorld(x[0]),Double.parseDouble(x[1]),Double.parseDouble(x[2]),Double.parseDouble(x[3]),Float.parseFloat(x[4]),Float.parseFloat(x[5])); }
    private ItemStack item(Material m, String name, String lore) { ItemStack i=new ItemStack(m); ItemMeta meta=i.getItemMeta(); meta.setDisplayName(ChatColor.AQUA+name); meta.setLore(List.of(ChatColor.GRAY+lore)); i.setItemMeta(meta); return i; }
    private void openMenu(Player p) {
        Inventory inv=Bukkit.createInventory(null,27,menuTitle);
        inv.setItem(10,item(Material.GRASS_BLOCK,"Spawn","Teleport to spawn"));
        inv.setItem(12,item(Material.EMERALD,"Shop","Buy items"));
        inv.setItem(14,item(Material.CHEST,"Crates","Crate menu"));
        inv.setItem(16,item(Material.GOLD_INGOT,"Balance","View your money"));
        p.openInventory(inv);
    }
    private void openShop(Player p) {
        Inventory inv=Bukkit.createInventory(null,27,ChatColor.DARK_BLUE+"HR Shop");
        inv.setItem(10,item(Material.IRON_INGOT,"Buy Iron ($50)","Click to buy 1"));
        inv.setItem(12,item(Material.GOLD_INGOT,"Buy Gold ($100)","Click to buy 1"));
        inv.setItem(14,item(Material.DIAMOND,"Buy Diamond ($250)","Click to buy 1"));
        inv.setItem(16,item(Material.BARRIER,"Close","Close shop"));
        p.openInventory(inv);
    }
    private void openCrates(Player p) {
        Inventory inv=Bukkit.createInventory(null,27,ChatColor.DARK_PURPLE+"HR Crates");
        inv.setItem(13,item(Material.TRIPWIRE_HOOK,"Starter Crate","Click to open (free demo reward)"));
        p.openInventory(inv);
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p=e.getPlayer(); loggedIn.remove(p.getUniqueId());
        p.sendMessage(ChatColor.AQUA+"Welcome to the server powered by HR Plugin!");
        if(p.getName().equalsIgnoreCase(dev)) p.sendMessage(ChatColor.GOLD+"Developer access recognized.");
        else if(users.contains(p.getUniqueId().toString())) p.sendMessage(ChatColor.YELLOW+"Please /login <password>");
        else p.sendMessage(ChatColor.YELLOW+"Please /register <password> <repeat>");
        if(getConfig().isString("spawn")) p.teleport(deserialize(getConfig().getString("spawn")));
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { loggedIn.remove(e.getPlayer().getUniqueId()); }
    @EventHandler public void onChat(AsyncPlayerChatEvent e) {
        Player p=e.getPlayer(); long now=System.currentTimeMillis(); long prev=lastChat.getOrDefault(p.getUniqueId(),0L);
        if(now-prev<1200 && !p.hasPermission("hr.bypass")) { e.setCancelled(true); p.sendMessage(ChatColor.RED+"Please slow down."); return; }
        lastChat.put(p.getUniqueId(),now);
        String msg=e.getMessage().toLowerCase(Locale.ROOT);
        if((msg.contains("developer") && (msg.contains("idiot") || msg.contains("abuse"))) && !p.getName().equalsIgnoreCase(dev)) {
            e.setCancelled(true); p.sendMessage(ChatColor.RED+"Please keep chat respectful.");
        }
    }
    @EventHandler public void onMove(PlayerMoveEvent e) {
        if(e.getTo()==null || e.getFrom().getBlockX()==e.getTo().getBlockX() && e.getFrom().getBlockZ()==e.getTo().getBlockZ()) return;
        Player p=e.getPlayer();
        if(!p.getName().equalsIgnoreCase(dev) && !p.hasPermission("hr.bypass") && users.contains(p.getUniqueId().toString()) && !loggedIn.contains(p.getUniqueId())) {
            e.setTo(e.getFrom()); return;
        }
    }
    @EventHandler public void onBlock(BlockPlaceEvent e) { if(isProtected(e.getPlayer(),e.getBlock())) { e.setCancelled(true); e.getPlayer().sendMessage(ChatColor.RED+"That land is protected."); } }
    @EventHandler public void onBreak(BlockBreakEvent e) { if(isProtected(e.getPlayer(),e.getBlock())) { e.setCancelled(true); e.getPlayer().sendMessage(ChatColor.RED+"That land is protected."); } }
    private boolean isProtected(Player p, Block b) {
        if(p.getName().equalsIgnoreCase(dev) || p.hasPermission("hr.bypass")) return false;
        UUID owner=claims.get(chunkKey(b.getLocation()));
        return owner!=null && !owner.equals(p.getUniqueId());
    }
    @EventHandler public void onInventory(InventoryClickEvent e) {
        if(!(e.getWhoClicked() instanceof Player p)) return;
        String title=e.getView().getTitle();
        if(title.equals(menuTitle) || title.equals(ChatColor.DARK_BLUE+"HR Shop") || title.equals(ChatColor.DARK_PURPLE+"HR Crates")) {
            e.setCancelled(true); if(e.getCurrentItem()==null) return;
            Material m=e.getCurrentItem().getType();
            if(title.equals(menuTitle)) {
                if(m==Material.GRASS_BLOCK) p.performCommand("spawn");
                if(m==Material.EMERALD) openShop(p);
                if(m==Material.CHEST) openCrates(p);
                if(m==Material.GOLD_INGOT) p.performCommand("balance");
            } else if(title.equals(ChatColor.DARK_BLUE+"HR Shop")) {
                Material buy=null; double price=0;
                if(m==Material.IRON_INGOT){buy=Material.IRON_INGOT;price=50;}
                if(m==Material.GOLD_INGOT){buy=Material.GOLD_INGOT;price=100;}
                if(m==Material.DIAMOND){buy=Material.DIAMOND;price=250;}
                if(buy!=null) { if(money(p)>=price){setMoney(p,money(p)-price);p.getInventory().addItem(new ItemStack(buy));p.sendMessage(ChatColor.GREEN+"Purchased "+buy);} else p.sendMessage(ChatColor.RED+"Not enough money."); }
                if(m==Material.BARRIER) p.closeInventory();
            } else if(m==Material.TRIPWIRE_HOOK) {
                p.getInventory().addItem(new ItemStack(Material.IRON_INGOT,8)); p.sendMessage(ChatColor.LIGHT_PURPLE+"Starter crate reward: 8 iron ingots.");
            }
        }
    }
    @EventHandler public void onEntitySpawn(EntitySpawnEvent e) {
        int max=getConfig().getInt("limits.max-entities-per-chunk",80);
        if(e.getLocation().getChunk().getEntities().length>max && (e.getEntity() instanceof Item || e.getEntity() instanceof ExperienceOrb)) e.setCancelled(true);
    }
    private void updateScoreboards() {
        for(Player p:Bukkit.getOnlinePlayers()) {
            Scoreboard board=Bukkit.getScoreboardManager().getNewScoreboard();
            Objective obj=board.registerNewObjective("hr","dummy",ChatColor.BLUE+"✦ "+ChatColor.AQUA+"HR SERVER");
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
            obj.getScore(ChatColor.GRAY+"Player: "+ChatColor.WHITE+p.getName()).setScore(4);
            obj.getScore(ChatColor.GRAY+"Balance: "+ChatColor.GREEN+"$"+(int)money(p)).setScore(3);
            obj.getScore(ChatColor.GRAY+"Online: "+ChatColor.WHITE+Bukkit.getOnlinePlayers().size()).setScore(2);
            obj.getScore(ChatColor.DARK_AQUA+"HRWasHere_").setScore(1);
            p.setScoreboard(board);
        }
    }
}
